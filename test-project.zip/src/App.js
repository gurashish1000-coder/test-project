import Header from './components/Header'
import LeftPanel from './components/LeftPanel'
import MiddlePanel from './components/MiddlePanel'
import RightPanel from './components/RightPanel'


const App = () => {

  /**
   * The layout main layout is divided into 4 components: Header, Left-Panel,
   * Middle-Panel, Right-Panel.
   */
  return (

    <div>
      <Header/>

      <div className='flex' >  
        <LeftPanel/>

        <div className='container'>
          <MiddlePanel/>
        </div>

        <RightPanel/>
      </div>
    </div>
  );
}
export default App;
