import React from 'react'

/**
 * A component to make creation of multiple buttons easier for web app. 
 * @param {function} onClick is function being passed/assigned to a button. 
 * @param {String} Color is the color the button will be
 * @param {String} text is the text to display on Button
 */
const Button = ({onClick, color, text}) => {

    return (
        <button onClick={onClick} style={{ backgroundColor: color }} className='btn'>
            {text}
        </button>
    )
}

export default Button
