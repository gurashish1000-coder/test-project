import Button from './Button'
import React from 'react'
import { useEffect, useState } from "react";
import TeacherItems from './TeacherItems' 

/**
 * Responsible for all the elements being shown in the right most container of the web app. 
 */
const RightPanel = () => {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [teacherItems, setTeacherItems] = useState([]);

    
    useEffect(() => {
        fetchTeachers()
    }, [])

    /**
     * Fetches the Teachers data from the api
     */
    const fetchTeachers= () =>{
        fetch("http://squigglepark-fullstack-project.us-east-1.elasticbeanstalk.com/api/teachers", { headers: {
            'Authorization': 'tf8P1869GRk2LVNej6YftLl95XNeWbFF',
            }})
            .then(res => res.json())
            .then(
            (result) => {
                setIsLoaded(true);
                setTeacherItems(result);
                },
            (error) => {
                setIsLoaded(true);
                setError(error);
                }
            )
    }

    if (error) {
        return <div>Error: {error.message}</div>;

    } else if (!isLoaded) {
        return <div>Loading...</div>;

    } else {
        return (
            <header className='containerList'>
                <div className='flex'>
                    <h2> List of Teachers: </h2>
                    <Button onClick={fetchTeachers} text='UPDATE' />
                </div>
                <div>
                    <TeacherItems items={teacherItems}> </TeacherItems>
                </div>
            </header>
        )
    }
}

export default RightPanel
