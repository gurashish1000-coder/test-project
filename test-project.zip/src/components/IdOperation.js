import React from 'react'
import { useState } from 'react'
import Button from './Button'
import TeacherItems from './TeacherItems' 

/**
 * This component implements id related opearations such as 'SEARCH' AND 'DELETE'
 */
const IdOperation = ({onGetTeacher}) => {
    const [id, setId] = useState('')
    const [error, setError] = useState(null);
    const [teacherItem, setTeacherItem] = useState([]);

    /**
     * This sends a GET request to API to get teacher with the required id 
     */
    const getTeacher = () => {

        if (!id) {
            alert('Please enter the Id of Teacher to search.')
            return
          }
        setTeacherItem([])
        setId('')
        fetch(`http://squigglepark-fullstack-project.us-east-1.elasticbeanstalk.com/api/teachers/${id}`, { headers: {
        'Authorization': 'tf8P1869GRk2LVNej6YftLl95XNeWbFF',
        }})
        .then(res => res.json())
        .then(
        (result) => {
            setTeacherItem([result]);
            },
        (error) => {
            setError(error);
            }
        )
    }

    /**
     * This sends a DELETE request to API to delete techaer with the required id 
     */
    const deleteTeacher = () =>{
        if (!id) {
            alert('Please enter the Id of Teacher to search.')
            return
        }
        setTeacherItem([])
        setId('')

        fetch(`http://squigglepark-fullstack-project.us-east-1.elasticbeanstalk.com/api/teachers/${id}`, {headers: {'Authorization': 'tf8P1869GRk2LVNej6YftLl95XNeWbFF'}, method: 'DELETE'})
        .then(console.log('Teacher deleted.'))
    }
    
    if (error) {
        return <div>Error: {error.message}</div>; 
    } else {
        return (
            <div className='idOperations'>
                <div className='form-control input'>
                    <label>Id Operations</label>
                    <div className='idOperations'>
                        <input
                                    type='text'
                                    placeholder='Id to search or delete'
                                    value={id}
                                    onChange={(e) => setId(e.target.value)}
                        />
                        <Button onClick={getTeacher} text='SEARCH'>  </Button>
                        <Button onClick={deleteTeacher} text='DELETE'>  </Button>
                    </div>
                    <TeacherItems items={teacherItem} id={id}></TeacherItems>
                </div>
            </div>       
        )
    }
}

export default IdOperation
