import React from 'react'

/**
 * Display the top Element of the web app.
 */
const Header = () => {
    return (
        <div>
            <section>
                <div className="header">
                    <h1>
                        TEST PROJECT
                    </h1>
                    <p>
                        BY- GURASHISH ARNEJA
                    </p>

                </div>
            </section>

        </div>
        
    )
}

export default Header
