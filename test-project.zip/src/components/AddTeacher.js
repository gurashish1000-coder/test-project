import { useState } from 'react'

/**
 * This component is reponsible for the form to be displayed on webapp. When Add Teacher button is pressed it calls
 * for the  method/function that is being passed to this component through onAdd.
 * @param {function} onAdd{addTecaher} function is being pased.
 */
const AddTeacher = ({onAdd}) => {
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [schoolCode, setSchoolCode] = useState('')

    /**
     * This gets executed on onSubmit/Add Teacher press. Executes the onAdd function in 
     * middlePanel.js
     */
    const onSubmit = (e) => {
        e.preventDefault()
    
        if (!firstName) {
          alert('Please add Teacher info')
          return
        }

        onAdd({ firstName, lastName, schoolCode })
        
        setFirstName('')
        setLastName('')
        setSchoolCode('')
    }
    

    return (
    <form className='add-form' onSubmit={onSubmit}>
      <div className='form-control'>

        <label>First Name</label>
        <input
          type='text'
          placeholder='Add First Name'
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
      </div>
      <div className='form-control'>
        <label>Last Name</label>
        <input
          type='text'
          placeholder='Add Last Name'
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
      </div>
      <div className='form-control'>
        <label>School Code</label>
        <input
          type='text'
          placeholder='Add School Code'
          value={schoolCode}
          onChange={(e) => setSchoolCode(e.target.value)}
        />
      </div>
      

      <input type='submit' value='Add Teacher' className='btn btn-block' />
    </form>
    )
}

export default AddTeacher
