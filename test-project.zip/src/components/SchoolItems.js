import Item from './Item'

/**
 * Displays all the elements of the provided schoolItems list.
 * @param {list} items contains a list of school objects.
 */
const SchoolItems = ({items}) => {
    return (
        <div>
            {items.map((item) =>(
                <Item key={item.id} item={item} type={'School'} /> 
            ))}
        </div>
    )
}

export default SchoolItems
