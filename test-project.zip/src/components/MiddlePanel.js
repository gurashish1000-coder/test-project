import AddTeacher from './AddTeacher'
import IdOperations from './IdOperation'

/**
 * Responsible for all the elements being shown in the middle container. 
 */
const MiddlePanel = () => {

    /**
     * This method issues a POST request to add a new teacher to a database. 
     * @param {object} teacher object contains the necessary information to register a teacher to a database.
     */
    const addTeacher = (teacher) =>{
        fetch('http://squigglepark-fullstack-project.us-east-1.elasticbeanstalk.com/api/teachers', {
        method: 'POST',
        headers: {
            'Authorization': 'tf8P1869GRk2LVNej6YftLl95XNeWbFF',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            firstName: teacher.firstName,
            lastName: teacher.lastName,
            schoolCode: teacher.schoolCode,
        })
        })
    }

    return (
        <div >
            <h1> Test Project</h1>
            <AddTeacher onAdd={addTeacher}> </AddTeacher>
            <IdOperations> </IdOperations>
        </div>
    )
}

export default MiddlePanel
