import Item from './Item'

/**
 * Displays all the elements of the provided teacherItems list.
 * @param {list} items contains a list of teacher objects.
 */
const TeacherItems = ({ items }) => {
    return (
        <div>
            {items.map((item) =>(
                <Item key={item.id} item={item} type={'Teacher'} /> 
            ))}
        </div>
    )
}

export default TeacherItems
