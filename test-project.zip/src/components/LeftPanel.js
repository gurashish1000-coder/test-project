import Button from './Button'
import React from 'react'
import { useEffect, useState } from "react";
import SchoolItems from './SchoolItems'

/**
 * Responsible for all the elements being shown in the left most container of the web app. 
 */
const LeftPanel = () => {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [schoolItems, setSchoolItems] = useState([]);


    useEffect(() => {
        fetchSchools()
    }, [])

    /**
     * Fetches the Schools data from the api 
     */
    const fetchSchools = () =>{
        fetch("http://squigglepark-fullstack-project.us-east-1.elasticbeanstalk.com/api/schools")
            .then(res => res.json())
            .then(
            (result) => {
                setIsLoaded(true);
                setSchoolItems(result);
            },
            (error) => {
                setIsLoaded(true);
                setError(error);
            }
            )
    }
    if (error) {
        return <div>Error: {error.message}</div>;

    } else if (!isLoaded) {
    return <div>Loading...</div>;

    } else{
        return (
            <header className='containerList'>
                <div className='flex'>
                    <h2> List of Schools: </h2>
                    <Button onClick={fetchSchools} text='UPDATE' />
                </div>
                
                <div>
                    <SchoolItems items={schoolItems}></SchoolItems>
                </div>
            </header>
        )
    }

    
}

export default LeftPanel
