/**
 * Component for displaying the individual list items for both(Schools and Teachers) with correct data.
 * @param {object} item can be either a school object or teacher object.  
 * @param {String} type will be either 'Teacher' or 'School', resulting in different info being displayed.
 */
const Item = ({item, type}) => {

    let content  = null

    if (type == 'Teacher') {
        if(item.id){
            content = <div className='item'>
                <h3>
                    {item.id} : {item.firstName} {item.lastName} 
                </h3>
                <p>{item.school.name}, {item.school.regionID}, {item.school.countryID},</p>
                <p>{item.school.schoolCode}</p>
            </div>    
        } else {
            content = <div className='item'>
                <h3>
                    {item.firstName} {item.lastName} 
                </h3>
                <p>{item.school.name}, {item.school.regionID}, {item.school.countryID},</p>
                <p>{item.school.schoolCode}</p>
            </div>
        }

    } else if (type == 'School') {
        content = <div className='item'>
                    <h3>
                        {item.name}
                    </h3>
                    <p>{item.regionID}, {item.countryID}, </p>
                    <p>{item.schoolCode}</p>
                </div>
    }

    return (
        content
    )
}

export default Item
